---------------------------------------------------------------
                         READ ME
---------------------------------------------------------------

The Python version used for this game is python 3.6
The CodeSkulptor link for this game is: https://py3.codeskulptor.org/#user303_7YFyTUFoSC_16.py

Requirements:
If the user is not using the CodeSkulptor link to run the game, 
then the user will need to have the SimpleGUICS2Pygame package 
downloaded.
If the user is using the CodeSkupltor link to run the game, 
then the user will have to load all of the image file links 
before running the program.

To start the game, open the myGame.py file in its current 
directory and run the file. This will start up the game in the
simplegui interface. Click on the main canvas of the game and 
follow the on screen instructions to start playing the game.

On the welcome screen there is two clickable icons, "Start", 
which starts the game, and 
"Help", which will provide the user with instructions on 
how to play the game.

At the side of the game window there is the controls for the 
game. 
	These controls are:
W : Forwards
S : Backwards
A : Left
D : Right
Mouse Click 1 : Shoot

Once the game is over the user will return to the welcome screen,
to Quit or to play again. 
To quit, the user will press "Exit" button on the canvas. 
To play again, the user will click on the "Start" that is 
displayed on the canvas.

----------------------------------------------------------------